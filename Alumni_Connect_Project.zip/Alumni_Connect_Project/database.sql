CREATE DATABASE IF NOT EXISTS alumni_db;
USE alumni_db;

CREATE TABLE admin (
    admin_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE,
    password CHAR(64) NOT NULL
);

CREATE TABLE alumni (
    alumni_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    batch INT NOT NULL,
    department VARCHAR(50) NOT NULL,
    email VARCHAR(100),
    company VARCHAR(100),
    job_role VARCHAR(100)
);

CREATE TABLE events (
    event_id INT PRIMARY KEY AUTO_INCREMENT,
    event_name VARCHAR(100) NOT NULL,
    event_date DATE NOT NULL,
    venue VARCHAR(100) NOT NULL
);

CREATE TABLE registrations (
    reg_id INT PRIMARY KEY AUTO_INCREMENT,
    alumni_id INT NOT NULL,
    event_id INT NOT NULL,
    UNIQUE (alumni_id, event_id),
    FOREIGN KEY (alumni_id) REFERENCES alumni(alumni_id) ON DELETE CASCADE,
    FOREIGN KEY (event_id) REFERENCES events(event_id) ON DELETE CASCADE
);

INSERT INTO admin(username, password)
VALUES ('admin', SHA2('admin123', 256));

INSERT INTO alumni (name, batch, department, email, company, job_role)
VALUES
('Arun Kumar', 2019, 'CSE', 'arun@mail.com', 'TCS', 'Software Engineer'),
('Priya Sharma', 2019, 'IT', 'priya@mail.com', 'Infosys', 'System Analyst'),
('Karthik Raja', 2020, 'ECE', 'karthik@mail.com', 'Zoho', 'Developer');

INSERT INTO events(event_name, event_date, venue)
VALUES
('Annual Alumni Meet', '2026-12-20', 'Main Auditorium'),
('Career Guidance Talk', '2026-11-15', 'Seminar Hall');

INSERT INTO registrations(alumni_id, event_id)
VALUES (1, 1), (2, 1), (3, 2);
